package json;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadJSONExample 
{
		static String path = System.getProperty("user.dir")+"\\src\\json\\GetProcessPlanFlowDiagram.json";

		@SuppressWarnings("unchecked")
	    public static void main(String[] args) 
	    {
			JSONParser parser = new JSONParser();
			try {
				Object obj = parser.parse(new FileReader(path));
				JSONArray array = new JSONArray();
				array.add(obj);
				JSONObject obj1=(JSONObject)JSONValue.parse(new FileReader(path)); 
				Object arr=obj1.get("result"); 
				System.out.println("result ::" + arr);
				
				arr=obj1.get("nodeDataArray"); 
				System.out.println("nodeDataArray ::" + arr);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	}


