package common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.IntPredicate;
import java.util.logging.Logger;

/**
 * This class contains all the common methods 
 * 
 */


@SuppressWarnings({ "unused" })
public class Common {


	// Generate Random Alphanumeric String
	public static String generatingRandomAlphanumericString(int targetStringLength) {

		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < targetStringLength) { // length of the random string.
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();

		return saltStr;
	}


	public HashMap<String, String> createUnitIDPostman1(String filename, String postmanURl, String Username, String UserId ,String batchID, String ProgramVal , String BarcodeLength , String Quantity, String SideVal) throws IOException {
		String inputdata = new String(Files.readAllBytes(Paths.get(System.getProperty("user.dir")+ "\\"+ filename)));
		System.out.println(inputdata);
		HashMap<String , String> UnitIDDetails = new HashMap<String , String>();
		int counter=0;
		do{
			String unitID= generatingRandomAlphanumericString(Integer.parseInt(BarcodeLength));
			String postInputData=inputdata.replace("Parent", unitID);
			UnitIDDetails.put("Parent", unitID);
			postInputData=postInputData.replace("BatchID", batchID);
			postInputData=postInputData.replace("Demo", ProgramVal);
			postInputData=postInputData.replace("totalqty", Quantity);
			postInputData=postInputData.replace("Top", SideVal);
			
			for(int i=1;i<=Integer.parseInt(Quantity);i++) {
				String ChildID=generatingRandomAlphanumericString(Integer.parseInt(BarcodeLength));
				postInputData=postInputData.replace("Child"+i, ChildID);
				UnitIDDetails.put("Child"+i, ChildID);
			}

			System.out.println(postInputData);
			URL obj = new URL(postmanURl);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Username", Username);
			postConnection.setRequestProperty("UserId", UserId);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			os.write(postInputData.getBytes());
			os.flush();
			os.close();
			int responseCode = postConnection.getResponseCode();
			System.out.println("POST Response Code :  " + responseCode);
			System.out.println("POST Response Message : " + postConnection.getResponseMessage());

			if(postConnection.getResponseMessage().contains("OK")) {
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in .readLine()) != null) {
					response.append(inputLine);
				} 
				in.close();
				System.out.println(response.toString());

				String [] splitsvalues=response.toString().split("\\,");
				for(int i=0;i<splitsvalues.length;i++) {
					if(splitsvalues[i].contains("status")) {
						System.out.println(splitsvalues[i]);
						String [] splitsSuccessStatus=splitsvalues[i].split("\\:");
						if(splitsSuccessStatus[1].contains("1")) {
							System.out.println("unit ID created successfully");
							UnitIDDetails.put("PostmanResult","Pass");
							break;
						}else {
							System.out.println("unit ID not created successfully");
							UnitIDDetails.put("PostmanResult","Fail");
						}
					}
				}
			}else {
				System.out.println("API is not working correctly");
				UnitIDDetails.put("PostmanResult","Fail");
			}
			counter++;
			if(counter>5) {
				break;
			}
		}while(UnitIDDetails.containsValue("Fail"));
		return UnitIDDetails;
	}
	
	public HashMap<String, String> createUnitIDPostman(String postmanURl, String Username, String UserId ,String batchID, String ProgramVal , String BarcodeLength , String Quantity, String SideVal) throws IOException {
		HashMap<String , String> UnitIDDetails = new HashMap<String , String>();
		int counter=0;
		String unitID= generatingRandomAlphanumericString(Integer.parseInt(BarcodeLength));
		UnitIDDetails.put("Parent", unitID);
		
		String fileContent = "{\n" + 
				"  \"entityType\": 101,\n" + 
				"  \"transaction\": \"CreateUnit\",\n" + 
				"  \"parameters\": [\n" + 
				"    {\n" + 
				"      \"name\": \"unitinfo\",\n" + 
				"      \"value\": {\n" + 
				"        \"Program\": \""+ProgramVal+"\",\n" + 
				"        \"Product\": \"\",\n" + 
				"        \"ProcessPlan\": \"\",\n" + 
				"        \"Units\": [\n" + 
				"          {\n" + 
				"            \"Barcode\": \""+unitID+"\",\n" + 
				"            \"Side\":\""+SideVal+"\",\n" + 
				"            \"SubUnits\": [\n" + 
				"               ";
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+ "\\postmanUpdatedInput.txt"));
		//writer.write(fileContent);
		System.out.println();
		
		
		do{
			for(int i=1;i<=Integer.parseInt(Quantity);i++) {
				String ChildID=generatingRandomAlphanumericString(Integer.parseInt(BarcodeLength));
				fileContent=fileContent+
						"{				\n" + 
						"                \"RefNumber\": \""+i+"\",\n" + 
						"                \"Barcode\": \""+ChildID+"\",\n" + 
						"                \"Side\":\""+SideVal+"\"\n" + 
						"              }";
				//writer.write(fileContent);
				if(i<Integer.parseInt(Quantity)){
						fileContent=fileContent+","+ 
								"          \n";
				}
				UnitIDDetails.put("Child"+i, ChildID);
			}

			fileContent=fileContent+
					" ]\n" + 
					"          }\n" + 
					"        ],\n" + 
					"         \"Batch\": {\"BatchNumber\": \""+batchID+"\",\"CreateBatch\": \"true\", \"Quantity\": \""+Quantity+"\",\"UpdateQty\": \"true\"  }\n" + 
					"      }\n" + 
					"    }\n" + 
					"  ]\n" + 
					"}\n" + 
					"";
			
			
			System.out.println(fileContent);
			writer.newLine();
			writer.write(fileContent);
			writer.newLine();
			writer.close();
			
			URL obj = new URL(postmanURl);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Username", Username);
			postConnection.setRequestProperty("UserId", UserId);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			os.write(fileContent.getBytes());
			os.flush();
			os.close();
			int responseCode = postConnection.getResponseCode();
			System.out.println("POST Response Code :  " + responseCode);
			System.out.println("POST Response Message : " + postConnection.getResponseMessage());

			if(postConnection.getResponseMessage().contains("OK")) {
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();
				while ((inputLine = in .readLine()) != null) {
					response.append(inputLine);
				} 
				in.close();
				System.out.println(response.toString());

				String [] splitsvalues=response.toString().split("\\,");
				for(int i=0;i<splitsvalues.length;i++) {
					if(splitsvalues[i].contains("status")) {
						System.out.println(splitsvalues[i]);
						String [] splitsSuccessStatus=splitsvalues[i].split("\\:");
						if(splitsSuccessStatus[1].contains("1")) {
							System.out.println("unit ID created successfully");
							UnitIDDetails.put("PostmanResult","Pass");
							break;
						}else {
							System.out.println("unit ID not created successfully");
							UnitIDDetails.put("PostmanResult","Fail");
						}
					}
				}
			}else {
				System.out.println("API is not working correctly");
				UnitIDDetails.put("PostmanResult","Fail");
			}
			counter++;
			if(counter>5) {
				break;
			}
		}while(UnitIDDetails.containsValue("Fail"));
		return UnitIDDetails;
	}
}
