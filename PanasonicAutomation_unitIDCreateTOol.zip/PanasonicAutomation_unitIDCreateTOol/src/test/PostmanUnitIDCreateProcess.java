package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import javax.swing.JOptionPane;

import common.Common;

public class PostmanUnitIDCreateProcess extends Common {

	public static void main(String[] args) throws IOException {
		Common common= new Common();
		HashMap<Integer,String> serialNumberList=  new HashMap<Integer,String>();
		FileWriter fw=new FileWriter(System.getProperty("user.dir")+ "\\postmanUnitIDOutPut.txt"); 
		File file = new File(System.getProperty("user.dir")+ "\\testdata.properties");
		FileInputStream fileInput = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(fileInput);
		try {
			HashMap<String, String> UnitIDDetails = common.createUnitIDPostman(prop.getProperty("PostmanURL"), prop.getProperty("PostmanUserName"), prop.getProperty("PostmanUserID"), prop.getProperty("batchID"),prop.getProperty("ProgramVal"),prop.getProperty("BarcodeLength"),prop.getProperty("Quantity"),prop.getProperty("SideVal"));
			if(UnitIDDetails.containsValue("Pass")) {
				System.out.println("Unit ID created");
				fw.write("Batch ID:: "+prop.getProperty("batchID"));
				fw.write("\r\n"); 
				fw.write("Parent Unit ID:: "+UnitIDDetails.get("Parent"));
				fw.write("\r\n"); 
				for(int p=1;p<UnitIDDetails.size();p++) {
					if(UnitIDDetails.containsKey("Child"+p)) {
						serialNumberList.put(p, UnitIDDetails.get("Child"+p));
						fw.write("Child ID "+p+"::"+UnitIDDetails.get("Child"+p));  
						fw.write("\r\n"); 
					}
				}
				System.out.println("UnitID:: " + UnitIDDetails.get("Parent"));
				System.out.println("Child UnitID details: " + serialNumberList);
				fw.close();
				JOptionPane.showMessageDialog(null, "Unit ID created", "InfoBox: " + "Success", JOptionPane.INFORMATION_MESSAGE);

			} else {
				System.out.println("Unit ID not created, either postman is down or any other issue");
				fw.write("Unit ID not created, either postman is down or any other issue"); 
				fw.close();
				JOptionPane.showMessageDialog(null, "Unable to create unitID", "InfoBox: " + "Failed", JOptionPane.INFORMATION_MESSAGE);
			}   
		}catch(Exception e) 
		{
			System.out.println(e);
			JOptionPane.showMessageDialog(null, "Unable to create unitID", "InfoBox: " + "Failed", JOptionPane.INFORMATION_MESSAGE);

		}


	}
}
